# Task Management System
## Replicates Trello
Uses Javascript to manage the client side and PHP to manage database/server side communication